#ifndef _MEDIAH_H
#define _MEDIAH_H

double sortearnumero();

double tirarmedia(double *p, int tamanho);


#endif